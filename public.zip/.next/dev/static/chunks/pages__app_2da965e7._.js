(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_8bac8163._.js",
  "static/chunks/node_modules_next_dist_client_5a8a528e._.js",
  "static/chunks/node_modules_next_dist_b3fb3b5f._.js",
  "static/chunks/node_modules_next_app_72f3d36f.js",
  "static/chunks/[next]_entry_page-loader_ts_742e4b53._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_7f09fef0._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js"
],
    source: "entry"
});
